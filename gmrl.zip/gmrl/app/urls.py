from django.urls import path
from .import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('',views.index,name='index'),
     path('aboutus',views.aboutus,name='aboutus'),
     path('package',views.packages,name='package'),
      path('test',views.test,name='test'),
      path('gallery',views.gallery,name='gallery'),
      path('blog',views.blog,name='blog'),
      path('branches',views.branches,name='branches'),
       path('contact',views.contact,name='contact'),
       path('ayush general/<int:id>/',views.ayushgeneral,name='ayush general'),
       path('booking',views.booking,name='booking'),
       
      
      
      
]
urlpatterns +=static(settings.STATIC_URL,document_root=settings.STATIC_ROOT) 

if settings.DEBUG:
    urlpatterns +=static(settings.MEDIA_URL,document_root =settings.MEDIA_ROOT)
